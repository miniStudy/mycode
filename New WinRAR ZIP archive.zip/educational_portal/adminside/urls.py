"""educational_portal URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from adminside import views as adminview
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', adminview.home, name='Admin Home'),
    path('send_mail/', adminview.mail_send, name='send_mail'),
    path('boards/', adminview.show_boards, name='boards'),
    path('insert_update_boards/',adminview.insert_update_boards,name='insert_update_boards'),
    path('delete_boards/', adminview.delete_boards, name='delete_boards'),
    
    # ---------------------------adminside auth-------------------------
    path('Admin_Login/', adminview.admin_login_page, name='Admin Login'),
    path('admin_login_handle/',adminview.admin_login_handle,name='admin_login_handle'),
    path('Admin_Forgot_Password/', adminview.admin_Forgot_Password, name='Admin_Forgot_Password'),
    path('admin_handle_forgot_password/',adminview.admin_handle_forgot_password, name='admin_handle_forgot_password'),
    path('Admin_Set_New_Password/',adminview.admin_Set_New_Password, name='Admin_Set_New_Password'),
    path('admin_handle_set_new_password/',adminview.admin_handle_set_new_password, name='admin_handle_set_new_password'),
    path('admin_logout/',adminview.admin_logout, name = 'admin_logout' ),

    # ==============================adminside Stds=========================

    path('stds/', adminview.show_stds, name='stds'),
    path('insert_update_stds/',adminview.insert_update_stds,name='insert_update_stds'),
    path('delete_stds/', adminview.delete_stds, name='delete_stds'),

     # ==============================adminside Announcements=========================
    
    path('announcements/', adminview.show_announcements, name='admin_announcements'),
    path('insert_update_announcements/',adminview.insert_update_announcements,name='insert_update_announcements'),
    path('delete_announcements/', adminview.delete_announcements, name='delete_announcements'),
]

