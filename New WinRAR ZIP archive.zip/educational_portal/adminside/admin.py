from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Boards)
admin.site.register(AdminData)
admin.site.register(Students)
admin.site.register(Announcements)
admin.site.register(Std)
admin.site.register(Batches)
admin.site.register(Packs)
